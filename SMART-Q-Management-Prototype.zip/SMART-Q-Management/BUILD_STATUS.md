# SMART-Q Management — Build and Demo Status

## Included
- React 18 + Vite student/admin frontend
- Java 21 + Spring Boot API source
- Supabase schema, RLS policies, storage setup, and admin authorization instructions
- Digital order tokens, order status workflow, queue/dashboard/report features in source
- Optional Razorpay integration in source (requires backend test keys and configuration)
- Deployment instructions for phone-friendly browser workflows

## Important validation status
This package is a renamed and prepared source project, not a verified live deployment. During packaging, frontend dependency installation timed out, so `npm run build` could not run because Vite dependencies were unavailable. Maven is not installed in this environment, so the Java backend could not be compiled here. The app has not been connected to the user's live Supabase or Razorpay accounts.

## Before external demonstration
1. Extract the ZIP and push the `project` folder contents to a GitHub repository.
2. Run `project/supabase/schema.sql` in the Supabase SQL Editor.
3. Configure frontend and backend environment variables using the `.env.example` files.
4. Deploy the backend using Docker and set `/api/health` as its health check.
5. Deploy the frontend with Vercel or Netlify and set `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and `VITE_API_URL`.
6. Create a student account and authorize the designated admin only through the trusted SQL procedure in `project/supabase/ADMIN_SETUP.md`.
7. Test student order → unique token → admin status update → student tracking using two separate browser sessions/devices.
8. For a reliable exam demo, use Pay at Counter unless Razorpay test mode has been configured and tested.

Never place database passwords, Supabase service-role keys, JWT secrets, or Razorpay secret keys in frontend variables or source control.
