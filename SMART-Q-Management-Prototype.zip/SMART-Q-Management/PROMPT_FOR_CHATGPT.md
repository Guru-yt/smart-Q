# Prompt for ChatGPT (copy everything below this line)

You are a senior full-stack engineer. I am a college student building "SMART-Q Management", a SMART-Q Management — Smart Canteen Management System. I will upload a ZIP with the project. Read ALL files first (start with `project/README.md`), then continue the work below. Make changes directly in the files and give me the full updated files, not just suggestions. Keep the existing blue SMART-Q Management design and working features. I am working mainly from a phone, so keep steps simple and browser-based.

## Stack and architecture
- Frontend: React 18 + Vite, react-router-dom, lucide-react (`project/frontend/src/App.jsx`, `lib.js`, `styles.css`).
- Backend: Java 21, Spring Boot 3.5, JdbcTemplate, Spring Security OAuth2 resource server (`project/backend/src/main/java/edu/campus/canteen/`: `ApiController`, `SecurityConfig`, `ApiExceptionHandler`, `RazorpayClient`).
- Database/Auth/Storage: Supabase (`project/supabase/schema.sql`, `ADMIN_SETUP.md`).
- Browser talks to Supabase Auth for login, then calls the Spring API with the Supabase JWT. The API connects to Supabase Postgres (use the SESSION POOLER connection string).
- Roles: `student` and `admin` stored in `profiles.role`. Admin is created only by running SQL (no public admin signup).

## Features already implemented
Student signup/login, password reset (Forgot password + /reset-password), live menu with search/categories, cart (saved in localStorage), checkout, server-priced orders, unique pickup token, order tracking, cancel order, notification bell (unread count, mark read, mark all read), profile. Payments: Pay at counter, and optional Pay online via Razorpay (create order, signature verification, "Pay now" retry, auto refund on cancel). Admin: dashboard stats, order queue with status workflow, menu create/edit/delete with image upload, reports. Backend returns `{ "message": ... }` errors, validates input, uses `APP_TIMEZONE` for "today".

## Deployment plan (all config via environment variables, never commit secrets)
- Backend: Docker (`project/backend/Dockerfile`) on Render/Railway, health check `/api/health`.
- Frontend: Vercel/Netlify (`vercel.json` and `public/_redirects` handle SPA routes).
- Env vars: see `project/backend/.env.example` and `project/frontend/.env.example`. Razorpay keys (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`) are backend-only.

## IMPORTANT: what is NOT verified
The code was only syntax-checked. It has NOT been built, run, or tested against a real Supabase project or Razorpay. Please:
1. Review every file for compile errors, type errors and logic bugs (especially `ApiController.java` SQL, generic types in `Map.of(...)`, and `SecurityConfig` JWT decoder for Supabase ES256/HS256 tokens).
2. Run mentally or with tools: `mvn clean package` and `npm install && npm run build`; fix any errors.
3. Verify the SQL in `schema.sql` runs cleanly in the Supabase SQL editor, and RLS/storage policies are correct.
4. Add automated tests (JUnit for order/payment/status rules, Vitest for key UI flows) if possible.
5. Add a Razorpay webhook endpoint (signature-verified) as a safety net for payments that complete after the browser closes.
6. Improve anything unclear, but do not remove working features or change the visual design without asking.

## Other files in the ZIP
- `ui-preview/smart-q-management-ui-preview.html`: static visual preview of 5 screens using the real stylesheet (sample data, not functional).
- `standalone-demo/smart-canteen.html`: an early single-file offline demo (localStorage only, no backend). Not part of the real app.

## How I want answers
Short explanation first, then the exact changed files in full (or clear diffs), then a numbered list of steps I must do myself (Supabase, hosting dashboards, env vars). Tell me clearly anything you could not test.
